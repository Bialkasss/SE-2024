package put.io.patterns.implement;

public class USBDeviceObserver implements SystemStateObserver {
    private int lastUSBDevices = -1; // Initial value to show that its unitialized

    @Override
    public void update(SystemMonitor monitor) {
        SystemState lastSystemState = monitor.getLastSystemState();
        int currentUSBDevices = lastSystemState.getUsbDevices();

        if (lastUSBDevices != -1) {
            if (currentUSBDevices > lastUSBDevices) {
                System.out.println("> Number of USB devices increased.");
            } else if (currentUSBDevices < lastUSBDevices) {
                System.out.println("> Number of USB devices decreased.");
            }
        }

        lastUSBDevices = currentUSBDevices; // Update lastUSBDevices for next comparison
    }
}

